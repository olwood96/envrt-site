import Link from "next/link";
import { Container } from "../ui/Container";
import { siteConfig } from "@/lib/config";

const footerLinks = [
  {
    heading: "Product",
    links: [
      { label: "How it works", href: "/#how-it-works" },
      { label: "Pricing", href: "/pricing" },
      { label: "Demo", href: "/demo" },
    ],
  },
  {
    heading: "Company",
    links: [
      { label: "Team", href: "/team" },
      { label: "Contact", href: "/contact" },
    ],
  },
  {
    heading: "Legal",
    links: [
      { label: "Privacy policy", href: "/privacy" },
      { label: "Terms of service", href: "/terms" },
    ],
  },
];

export function Footer() {
  return (
    <footer className="border-t border-envrt-charcoal/5 bg-envrt-offwhite py-16">
      <Container>
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
          {/* Brand */}
          <div>
            <Link
              href="/"
              className="text-lg font-bold tracking-tight text-envrt-charcoal"
            >
              {siteConfig.name}
            </Link>
            <p className="mt-3 text-sm leading-relaxed text-envrt-muted">
              {siteConfig.tagline}
            </p>
            <p className="mt-2 text-xs text-envrt-muted/60">
              {siteConfig.contact.email}
            </p>
          </div>

          {/* Link columns */}
          {footerLinks.map((col) => (
            <div key={col.heading}>
              <h4 className="mb-3 text-xs font-medium uppercase tracking-widest text-envrt-muted">
                {col.heading}
              </h4>
              <ul className="space-y-2">
                {col.links.map((link) => (
                  <li key={link.href}>
                    <Link
                      href={link.href}
                      className="text-sm text-envrt-charcoal/70 transition-colors hover:text-envrt-teal"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-4 border-t border-envrt-charcoal/5 pt-8 sm:flex-row">
          <p className="text-xs text-envrt-muted">
            &copy; {new Date().getFullYear()} {siteConfig.name}. All rights reserved.
          </p>
          <p className="text-xs text-envrt-muted/50">
            Built for a more sustainable fashion industry.
          </p>
        </div>
      </Container>
    </footer>
  );
}
