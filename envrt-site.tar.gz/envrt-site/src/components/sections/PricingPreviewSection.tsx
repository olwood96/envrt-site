"use client";

import { Container } from "../ui/Container";
import { SectionCard } from "../ui/SectionCard";
import { Button } from "../ui/Button";
import { FadeUp, StaggerChildren, StaggerItem } from "../ui/Motion";
import { pricingPlans } from "@/lib/config";

export function PricingPreviewSection() {
  return (
    <div className="px-4 py-8 sm:px-6" id="pricing-preview">
      <SectionCard className="mx-auto max-w-[1360px]">
        <Container className="py-16 sm:py-20">
          <FadeUp>
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-xs font-medium uppercase tracking-widest text-envrt-teal">
                Pricing
              </p>
              <h2 className="mt-3 text-3xl font-bold tracking-tight text-envrt-charcoal sm:text-4xl">
                Simple, transparent plans
              </h2>
              <p className="mt-4 text-base text-envrt-muted">
                From your first DPP to full sustainability operations. Scale as you grow.
              </p>
            </div>
          </FadeUp>

          <StaggerChildren className="mt-14 grid gap-5 lg:grid-cols-3">
            {pricingPlans.map((plan) => (
              <StaggerItem key={plan.name}>
                <div
                  className={`relative flex flex-col rounded-2xl border p-8 transition-all duration-300 ${
                    plan.highlighted
                      ? "border-envrt-teal/30 bg-white shadow-xl shadow-envrt-teal/5"
                      : "border-envrt-charcoal/5 bg-white hover:border-envrt-charcoal/10"
                  }`}
                >
                  {plan.highlighted && (
                    <div className="absolute -top-3 left-6 rounded-full bg-envrt-teal px-3 py-1 text-[10px] font-semibold uppercase tracking-widest text-white">
                      Most popular
                    </div>
                  )}
                  <div>
                    <h3 className="text-lg font-bold text-envrt-charcoal">
                      {plan.name}
                    </h3>
                    <p className="mt-1 text-sm font-medium text-envrt-teal">
                      {plan.subheading}
                    </p>
                  </div>
                  <div className="mt-5">
                    <span className="text-3xl font-bold text-envrt-charcoal">
                      {plan.price}
                    </span>
                    <span className="text-sm text-envrt-muted">{plan.period}</span>
                  </div>
                  <p className="mt-3 text-sm text-envrt-muted">{plan.description}</p>
                  <ul className="mt-6 flex-1 space-y-2.5">
                    {plan.features.slice(0, 5).map((f) => (
                      <li
                        key={f}
                        className="flex items-start gap-2 text-sm text-envrt-charcoal/80"
                      >
                        <svg
                          className="mt-0.5 h-4 w-4 flex-shrink-0 text-envrt-teal"
                          viewBox="0 0 16 16"
                          fill="currentColor"
                        >
                          <path d="M13.78 4.22a.75.75 0 010 1.06l-7.25 7.25a.75.75 0 01-1.06 0L2.22 9.28a.75.75 0 011.06-1.06L6 10.94l6.72-6.72a.75.75 0 011.06 0z" />
                        </svg>
                        {f}
                      </li>
                    ))}
                    {plan.features.length > 5 && (
                      <li className="text-xs text-envrt-muted">
                        + {plan.features.length - 5} more features
                      </li>
                    )}
                  </ul>
                  <div className="mt-8">
                    <Button
                      href="/pricing"
                      variant={plan.highlighted ? "primary" : "secondary"}
                      className="w-full"
                    >
                      {plan.cta}
                    </Button>
                  </div>
                </div>
              </StaggerItem>
            ))}
          </StaggerChildren>

          <FadeUp delay={0.2}>
            <p className="mt-10 text-center text-sm text-envrt-muted">
              All plans include a 14-day free trial. No credit card required.{" "}
              <a href="/pricing" className="text-envrt-teal hover:underline">
                View full comparison →
              </a>
            </p>
          </FadeUp>
        </Container>
      </SectionCard>
    </div>
  );
}
