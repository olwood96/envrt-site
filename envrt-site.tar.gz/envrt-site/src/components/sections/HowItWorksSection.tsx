"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Container } from "../ui/Container";
import { SectionCard } from "../ui/SectionCard";
import { FadeUp } from "../ui/Motion";
import { howItWorksSteps } from "@/lib/config";

function MockMedia({ src, verb }: { src: string; verb: string }) {
  const [failed, setFailed] = useState(false);
  const [loaded, setLoaded] = useState(false);

  // Reset state when src changes
  useEffect(() => {
    setFailed(false);
    setLoaded(false);
  }, [src]);

  const isVideo = /\.(mp4|mov|webm)$/i.test(src);

  return (
    <div className="relative aspect-[4/3] w-full overflow-hidden rounded-xl border border-envrt-charcoal/5 bg-gradient-to-br from-envrt-cream to-white">
      {/* Fallback — always rendered underneath, hidden when media loads */}
      {(!loaded || failed) && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-gradient-to-br from-envrt-green/[0.02] to-envrt-teal/[0.06]">
          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-envrt-teal/10 text-2xl font-bold text-envrt-teal">
            {verb[0]}
          </div>
          <p className="text-sm font-medium text-envrt-charcoal/40">{verb}</p>
        </div>
      )}

      {/* Actual media — try to load on top */}
      {!failed && (
        <>
          {isVideo ? (
            <video
              key={src}
              src={src}
              autoPlay
              muted
              loop
              playsInline
              className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-300 ${loaded ? "opacity-100" : "opacity-0"}`}
              onLoadedData={() => setLoaded(true)}
              onError={() => setFailed(true)}
            />
          ) : (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              key={src}
              src={src}
              alt={`${verb} step`}
              className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-300 ${loaded ? "opacity-100" : "opacity-0"}`}
              onLoad={() => setLoaded(true)}
              onError={() => setFailed(true)}
            />
          )}
        </>
      )}
    </div>
  );
}

export function HowItWorksSection() {
  const [active, setActive] = useState(0);
  const step = howItWorksSteps[active];

  return (
    <div className="px-4 py-8 sm:px-6" id="how-it-works">
      <SectionCard className="mx-auto max-w-[1360px]">
        <Container className="py-16 sm:py-20">
          <FadeUp>
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-xs font-medium uppercase tracking-widest text-envrt-teal">
                How it works
              </p>
              <h2 className="mt-3 text-3xl font-bold tracking-tight text-envrt-charcoal sm:text-4xl">
                From data to DPP in under an hour
              </h2>
            </div>
          </FadeUp>

          {/* Tabs */}
          <FadeUp delay={0.1}>
            <div className="mx-auto mt-12 flex max-w-lg justify-center gap-2">
              {howItWorksSteps.map((s, i) => (
                <button
                  key={s.id}
                  onClick={() => setActive(i)}
                  className={`relative rounded-xl px-5 py-2.5 text-sm font-medium transition-all duration-300 ${
                    active === i
                      ? "bg-envrt-green text-white shadow-md"
                      : "text-envrt-charcoal/60 hover:bg-envrt-charcoal/5"
                  }`}
                >
                  {s.verb}
                  {active === i && (
                    <motion.div
                      layoutId="activeTab"
                      className="absolute inset-0 rounded-xl bg-envrt-green"
                      style={{ zIndex: -1 }}
                      transition={{ type: "spring", stiffness: 300, damping: 30 }}
                    />
                  )}
                </button>
              ))}
            </div>
          </FadeUp>

          {/* Content */}
          <div className="mt-12 grid items-center gap-10 lg:grid-cols-2 lg:gap-16">
            <AnimatePresence mode="wait">
              <motion.div
                key={step.id}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                transition={{ duration: 0.3 }}
              >
                <div className="flex items-center gap-3">
                  <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-envrt-teal/10 text-sm font-bold text-envrt-teal">
                    {active + 1}
                  </span>
                  <h3 className="text-xl font-semibold text-envrt-charcoal sm:text-2xl">
                    {step.title}
                  </h3>
                </div>
                <p className="mt-4 text-base leading-relaxed text-envrt-muted">
                  {step.description}
                </p>
                <ul className="mt-5 space-y-2.5">
                  {step.bullets.map((b) => (
                    <li key={b} className="flex items-start gap-2.5 text-sm text-envrt-charcoal/80">
                      <span className="mt-1.5 h-1.5 w-1.5 flex-shrink-0 rounded-full bg-envrt-teal" />
                      {b}
                    </li>
                  ))}
                </ul>
              </motion.div>
            </AnimatePresence>

            <AnimatePresence mode="wait">
              <motion.div
                key={step.id + "-media"}
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                transition={{ duration: 0.3 }}
              >
                <MockMedia src={step.mockImage} verb={step.verb} />
              </motion.div>
            </AnimatePresence>
          </div>
        </Container>
      </SectionCard>
    </div>
  );
}
