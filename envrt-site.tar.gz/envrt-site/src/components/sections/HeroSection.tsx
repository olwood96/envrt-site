"use client";

import { Container } from "../ui/Container";
import { SectionCard } from "../ui/SectionCard";
import { Button } from "../ui/Button";
import { Badge } from "../ui/Badge";
import { VideoFrame } from "../ui/VideoFrame";
import { FadeUp } from "../ui/Motion";
import { heroContent } from "@/lib/config";

export function HeroSection() {
  return (
    <div className="px-4 pt-28 sm:px-6 sm:pt-32">
      <SectionCard className="mx-auto max-w-[1360px] bg-gradient-to-br from-white via-envrt-cream/50 to-envrt-teal/[0.03]">
        <Container className="py-16 sm:py-20 lg:py-24">
          <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-16">
            {/* Left — copy */}
            <div className="max-w-xl">
              <FadeUp>
                <Badge>{heroContent.badge}</Badge>
              </FadeUp>

              <FadeUp delay={0.1}>
                <h1 className="mt-6 text-4xl font-bold leading-[1.1] tracking-tight text-envrt-charcoal sm:text-5xl lg:text-[3.4rem]">
                  {heroContent.headline.split("\n").map((line, i) => (
                    <span key={i}>
                      {line}
                      {i < heroContent.headline.split("\n").length - 1 && <br />}
                    </span>
                  ))}
                </h1>
              </FadeUp>

              <FadeUp delay={0.2}>
                <p className="mt-6 text-base leading-relaxed text-envrt-muted sm:text-lg">
                  {heroContent.subheadline}
                </p>
              </FadeUp>

              <FadeUp delay={0.3}>
                <div className="mt-8 flex flex-wrap gap-3">
                  <Button href={heroContent.ctaPrimary.href} size="lg">
                    {heroContent.ctaPrimary.label}
                    <span className="ml-2">→</span>
                  </Button>
                  <Button
                    href={heroContent.ctaSecondary.href}
                    variant="secondary"
                    size="lg"
                  >
                    {heroContent.ctaSecondary.label}
                  </Button>
                </div>
              </FadeUp>
            </div>

            {/* Right — device frame video */}
            <FadeUp delay={0.2}>
              <VideoFrame
                src={heroContent.videoSrc}
                label={heroContent.videoLabel}
                className="lg:pl-4"
              />
            </FadeUp>
          </div>
        </Container>
      </SectionCard>
    </div>
  );
}
