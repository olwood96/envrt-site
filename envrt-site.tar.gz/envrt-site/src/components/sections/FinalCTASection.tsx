"use client";

import { Container } from "../ui/Container";
import { SectionCard } from "../ui/SectionCard";
import { Button } from "../ui/Button";
import { FadeUp } from "../ui/Motion";

export function FinalCTASection() {
  return (
    <div className="px-4 py-8 sm:px-6">
      <SectionCard
        dark
        className="mx-auto max-w-[1360px]"
      >
        <Container className="py-20 sm:py-28">
          <FadeUp>
            <div className="mx-auto max-w-2xl text-center">
              <h2 className="text-3xl font-bold tracking-tight sm:text-4xl lg:text-5xl">
                Ready to show the world your impact?
              </h2>
              <p className="mt-5 text-base leading-relaxed text-white/60 sm:text-lg">
                Join the brands turning sustainability data into competitive advantage.
                Get your first Digital Product Passport in under an hour.
              </p>
              <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
                <Button
                  href="/contact"
                  size="lg"
                  className="bg-white text-envrt-green hover:bg-envrt-cream"
                >
                  Book a demo
                  <span className="ml-2">→</span>
                </Button>
                <Button
                  href="/pricing"
                  variant="ghost"
                  size="lg"
                  className="text-white/70 hover:text-white border border-white/20 hover:border-white/40"
                >
                  View pricing
                </Button>
              </div>
            </div>
          </FadeUp>
        </Container>
      </SectionCard>
    </div>
  );
}
